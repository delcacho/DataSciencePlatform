import argparse

print("Hola mundo")
